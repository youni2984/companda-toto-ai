'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
test('Sites builder includes history audit and result ledger routes', () => {
  const source = fs.readFileSync('scripts/build-sites.mjs','utf8');
  assert.match(source, /route==='\/api\/history-audit'/);
  assert.match(source, /route==='\/api\/results'/);
});
test('server contains separated ledgers', () => {
  const source = fs.readFileSync('server.js','utf8');
  assert.match(source, /let resultLedger = \{\}/);
  assert.match(source, /let historyAudit =/);
});
