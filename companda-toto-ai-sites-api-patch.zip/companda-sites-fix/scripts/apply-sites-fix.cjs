'use strict';
// Apply the missing Cloudflare/Sites route mappings to the existing project.
const fs = require('node:fs');
const path = require('node:path');
const root = process.cwd();
const serverPath = path.join(root, 'server.js');
const builderPath = path.join(root, 'scripts', 'build-sites.mjs');
if (!fs.existsSync(serverPath) || !fs.existsSync(builderPath)) {
  throw new Error('Run from the companda-toto-ai repository root (server.js and scripts/build-sites.mjs required).');
}
const server = fs.readFileSync(serverPath, 'utf8');
for (const marker of ['let resultLedger = {}', 'let historyAudit =', 'function auditHistoryPayload(']) {
  if (!server.includes(marker)) throw new Error(`server.js missing prerequisite: ${marker}. Apply PR #5 first.`);
}
let builder = fs.readFileSync(builderPath, 'utf8');
const routes = [
  " if(route==='/api/history-audit' && request.method==='GET')return json(historyAudit);",
  " if(route==='/api/results' && request.method==='GET')return json({rows:Object.values(resultLedger)});"
];
if (!builder.includes("route==='/api/history-audit'")) {
  const anchor = " if(route==='/api/config')";
  if (!builder.includes(anchor)) throw new Error('Sites builder API route anchor not found; no files modified.');
  builder = builder.replace(anchor, routes.join('\n') + '\n' + anchor);
  fs.writeFileSync(builderPath, builder);
  console.log('Patched Sites builder routes.');
} else console.log('Sites builder already contains history-audit route.');
console.log('Next: npm test && npm run build:sites; verify dist/server/index.js contains both API routes.');
