COMPANDA TOTO AI — ChatGPT Sites API route fix (2026-11-09)

IMPORTANT: This is a PATCH PACKAGE, NOT a standalone deployable application.
It does not repair missing historical source data or add durable database storage.

Prerequisites:
- Existing repository: youni2984/companda-toto-ai
- server.js from merged PR #5 must already be present
- Back up current production data and code before applying

Usage (from repository root):
1. Extract this ZIP into a temporary folder.
2. Copy scripts/apply-sites-fix.cjs to repository scripts/ directory.
3. Run: node scripts/apply-sites-fix.cjs
4. Run: npm test
5. Run: npm run build:sites
6. Run: node --test test/sites-routes.test.cjs (after copying test file into repository)
7. Check generated dist/server/index.js has /api/history-audit and /api/results.
8. Preview and test endpoints in Sites BEFORE publishing.

Caveats:
- The Sites builder creates a new application() per request. In-memory ledgers and audit
  state will reset; /api/results can be empty and /api/history-audit can show no fetched data.
  Persistent storage and provider-based history fetch require separate backend work.
- A successful JSON response only confirms route presence, not historical data integrity.
- Do not publish as a complete four-error fix without additional tests and persistent DB.
